package com.oblador.keychain.exceptions;

public class EmptyParameterException extends Exception {
    public EmptyParameterException(String message) {
        super(message);
    }
}
